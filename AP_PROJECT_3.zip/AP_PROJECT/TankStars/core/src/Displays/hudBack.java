/*package Displays;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankStars;

public class hudBack  {
    public Stage stage;
    private Viewport viewport;

    private Integer fuelLimit;
    private float timeCount;
    private Integer score;


    Label fuelLimitLabel;
    Label scoreLabel;
    Label fuelLabel;
    Label modeLabel;
    Label worldLabel;
    Label PlayerLabel;

    public hudBack(SpriteBatch spBatch){
        fuelLimit = 100;
        score=0;

        viewport = new FitViewport(tankStars.widthView, tankStars.heightView, new OrthographicCamera());
        stage = new Stage(viewport,spBatch);

        Table table = new Table();
        table.top();
        table.setFillParent(true);

        fuelLimitLabel = new Label(String.format("%03d",fuelLimit), new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(new BitmapFont(), Color.WHITE));
        scoreLabel = new Label(String.format("Coins: %03d", score), new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(new BitmapFont(), Color.WHITE));
        fuelLabel = new Label("FUEL", new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(new BitmapFont(), Color.BROWN));
        modeLabel = new Label("FOREST", new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(new BitmapFont(), Color.WHITE));
        worldLabel = new Label("MODE", new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(new BitmapFont(), Color.BROWN));
        PlayerLabel = new Label("PLAYER", new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(new BitmapFont(), Color.BROWN));

        table.add(PlayerLabel).expandX().padTop(10);
        table.add(worldLabel).expandX().padTop(10);
        table.add(fuelLabel).expandX().padTop(10);
        table.row();
        table.add(scoreLabel).expandX();
        table.add(modeLabel).expandX();
        table.add(fuelLimitLabel).expandX();

        stage.addActor(table);

    }
}
*/