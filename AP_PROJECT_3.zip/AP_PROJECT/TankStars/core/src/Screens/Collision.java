package Screens;

import com.badlogic.gdx.maps.tiled.renderers.IsometricTiledMapRenderer;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.physics.box2d.*;

import java.util.ArrayList;

public class Collision implements ContactListener {



    public ArrayList<Collision> collides = new ArrayList<Collision>();
    @Override
    public void beginContact(Contact contact) {
        Fixture a = contact.getFixtureA();
        Fixture b = contact.getFixtureB();

        if(a.getUserData()== null || b.getUserData()== null){
            return;
        }


        //System.out.println(a.getUserData() + " " + b.getUserData());
//       if(a.getUserData().equals("box") || b.getUserData().equals("ground")||a.getUserData().equals("ground") || b.getUserData().equals("box")){
//           System.out.println("tank 1 touched the ground");
//       }
//       if (a.getUserData().equals("ground")&&b.getUserData().equals("box2")||a.getUserData().equals("box2")&&b.getUserData().equals("ground")){
//           System.out.println("tank 2 touched the ground");
//       }
       if(a.getUserData().equals("ground")&&b.getUserData().equals("ball1")||a.getUserData().equals("ball1")&&b.getUserData().equals("ground")){
           System.out.println("ball 1 touched the ground");
           if(a.getUserData().equals("ball1")){
//               a.getBody().applyAngularImpulse(90000,true);
//               a.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//               a.getBody().getPosition().x+=20000000;
//               a.getBody().getPosition().y+=20000000;

           }

           if(b.getUserData().equals("ball1")) {
//               b.getBody().applyAngularImpulse(90000,true);
//               b.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//               b.getBody().getPosition().x+=20000000;
//               b.getBody().getPosition().y+=20000000;
           }
       }
        if(a.getUserData().equals("ground")&&b.getUserData().equals("ball2")||a.getUserData().equals("ball2")&&b.getUserData().equals("ground")){
            System.out.println("ball2 touched the ground");
            if(a.getUserData().equals("ball2")){
//                a.getBody().applyAngularImpulse(90000,true);
//                a.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//                a.getBody().getPosition().x+=20000000;
//                a.getBody().getPosition().y+=20000000;
            }

            if(b.getUserData().equals("ball2")) {
//                b.getBody().applyAngularImpulse(90000,true);
//                b.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//                b.getBody().getPosition().x+=20000000;
//                b.getBody().getPosition().y+=20000000;
            }
        }
        if(a.getUserData().equals("box2")&&b.getUserData().equals("ball1")||a.getUserData().equals("ball1")&&b.getUserData().equals("box2")){
            System.out.println("tank 1 exploded tank 2");
            Play.c1=Play.c1 + 1;

            if(a.getUserData().equals("ball1")){
//                a.getBody().applyAngularImpulse(90000,true);
//                a.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//                a.getBody().getPosition().x+=20000000;
//                a.getBody().getPosition().y+=20000000;
            }

            if(b.getUserData().equals("ball1")) {
//                b.getBody().applyAngularImpulse(90000,true);
//                b.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//                b.getBody().getPosition().x+=20000000;
//                b.getBody().getPosition().y+=20000000;

            }

        }
        if(a.getUserData().equals("box")&&b.getUserData().equals("ball2")||a.getUserData().equals("box")&&b.getUserData().equals("ball2")){
            System.out.println("tank 2 exploded tank 1");
            Play.c=Play.c +1;

            if(a.getUserData().equals("ball1")){
//                a.getBody().applyAngularImpulse(90000,true);
//                a.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//                a.getBody().getPosition().x+=20000000;
//                a.getBody().getPosition().y+=20000000;
            }

            if(b.getUserData().equals("ball1")) {
//                b.getBody().applyAngularImpulse(90000,true);
//                b.getBody().applyForce(9000000,9000000,b.getBody().getWorldCenter().x+2000,b.getBody().getWorldCenter().y+2000,true);
//                b.getBody().getPosition().x+=20000000;
//                b.getBody().getPosition().y+=20000000;
            }

        }
    }

    @Override
    public void endContact(Contact contact) {

    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {

    }
}
