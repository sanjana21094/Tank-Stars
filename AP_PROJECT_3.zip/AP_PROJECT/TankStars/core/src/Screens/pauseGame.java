package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

public class pauseGame implements Screen {

    private tankStars inGame;
    private Stage stage;
    private Texture tempPause;
    private OrthographicCamera pauseCam;
    private InputEvent event;
    private Skin skin;
    private TextButton resumeG;
    private TextButton saveG;
    private TextButton exitG;

    private Texture saveGamet;

    public pauseGame(tankStars inGame) {
        this.inGame= inGame;
        Gdx.input.setInputProcessor(stage);
        tempPause= new Texture("IN GAME.jpg");
        saveGamet = new Texture("SAVED GAME.jpg");
        pauseCam = new OrthographicCamera();
        stage = new Stage(new StretchViewport(1920,1080,pauseCam));
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));

    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        stage.draw();
        inGame.batch.setProjectionMatrix(pauseCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    }

    @Override
    public void render(float delta) {
        update(delta);
        inGame.batch.begin();
        inGame.batch.draw(tempPause, 0, 0, 1920, 1080);
        inGame.batch.end();
        stage.act();
        stage.draw();
        pauseButtons();

    }
    public void update(float delta){
        stage.act(delta);

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        inGame.batch.dispose();
        stage.dispose();

    }

    private void pauseButtons(){
        resumeG = new TextButton("RESUME GAME",skin);
        resumeG.setPosition(700, 600);
        resumeG.setSize(500, 100);
        resumeG.getLabel().setFontScale(4);
        resumeG.setColor(0,0,0,0);
        stage.addActor(resumeG);


        saveG = new TextButton("SAVE GAME",skin);
        saveG.setPosition(700, 400);
        saveG.setSize(500, 100);
        saveG.getLabel().setFontScale(4);
        saveG.setColor(0,0,0,0);
        stage.addActor(saveG);


        exitG = new TextButton("EXIT GAME",skin);
        exitG.setPosition(700,150);
        exitG.setSize(500, 100);
        exitG.getLabel().setFontScale(4);
        exitG.setColor(0,0,0,0);

        resumeG.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                inGame.setScreen(new resGame(inGame));
            }
        });

        exitG.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                System.exit(0);
            }
        });
        inGame.batch.begin();
        stage.addActor(resumeG);
        stage.addActor(resumeG);
        stage.addActor(exitG);
        inGame.batch.end();

    }
}