package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

public class vsTemp implements Screen {
    private tankStars vs;
    private Stage stage;
    private Skin skin;
    private Texture temp;

    private TextButton next;
    private OrthographicCamera vsCam;
    public static Sprite spriteF;
    public static Sprite spriteB;

    private InputEvent event;

    public vsTemp(tankStars vs) {
        this.vs = vs;
        Gdx.input.setInputProcessor(stage);
        vsCam = new OrthographicCamera();
        stage = new Stage();
        skin = new Skin();
        temp = new Texture("vstemp.jpg");
        stage = new Stage(new StretchViewport(1920,1080,vsCam));
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));

    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        stage.draw();
        vs.batch.setProjectionMatrix(vsCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    }

    @Override
    public void render(float delta) {
        update(delta);
        vs.batch.begin();
        vs.batch.draw(temp, 0, 0, 1920, 1080);
        player1Choose();
        player2Choose();
        vs.batch.end();
//        if(Gdx.input.isTouched()){
//            vs.setScreen(new Play(vs));
//        }
        stage.act();
        stage.draw();
        nextButton();

    }

    public void update(float delta){
        stage.act(delta);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
        vs.batch.dispose();

    }

    void player1Choose(){
        if(chooseTank.c==1){
            spriteF = new Sprite(new Texture("tank1.jpg"));
            vs.batch.draw(spriteF, -40, 240, 860, 364);
        }
        if(chooseTank.c==2){
            spriteF = new Sprite(new Texture("tank 2.jpg"));
            vs.batch.draw(spriteF, 20, 240, 600, 320);
        }
        if(chooseTank.c==3){
            spriteF = new Sprite(new Texture("TANK3.jpg"));
            vs.batch.draw(spriteF, -100, 180, 864, 364);
        }
    }

    void player2Choose(){
        if(choose.c1==1){
            spriteB = new Sprite(new Texture("tank1.jpg"));
            vs.batch.draw(spriteB, 1100, 260, 860, 364);
        }
        if(choose.c1==2){
            spriteB = new Sprite(new Texture("tank 2.jpg"));
            vs.batch.draw(spriteB, 1200, 260, 600, 320);
        }
        if(choose.c1==3){
            spriteB = new Sprite(new Texture("TANK3.jpg"));
            vs.batch.draw(spriteB, 1050, 180, 860, 364);
        }
    }

    private void nextButton(){
        next = new TextButton("next", skin);
        next.setPosition(700,500);
        next.setSize(500,100);
        next.getLabel().setFontScale(2);
        next.setColor(1,1,1,1);
        stage.addActor(next);

        next.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                vs.setScreen(new Play(vs));
            }
        });
    }

}