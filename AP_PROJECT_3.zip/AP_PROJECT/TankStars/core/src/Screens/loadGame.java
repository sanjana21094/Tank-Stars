package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.InputController;
import com.mygdx.game.tankStars;
import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;

public class loadGame implements Screen {



    private tankStars load;
    private Stage stage;
    private World world;
    private Box2DDebugRenderer b2dr;
    private OrthographicCamera playCam;
    private float speed = 100000;
    private float speed2 = 100000;
    private Vector2 movement = new Vector2();
    private Vector2 movement2 = new Vector2();

    private Body box;
    private Body box2;
    private Texture main;

    private Sprite fuel1;
    private Sprite fuel2;
    private Sprite fuel3;
    private Sprite fuel4;

    private Sprite fuel1t2;
    private Sprite fuel2t2;
    private Sprite fuel3t2;
    private Sprite fuel4t2;

    private Sprite h11;
    private Sprite h12;
    private Sprite h13;

    private Sprite h21;
    private Sprite h22;
    private Sprite h23;

    private TextButton pauseG;


    private Body fire1;
    private Texture fire2;


    private InputEvent event;

    private Skin skin;
    private Image options;

    private com.badlogic.gdx.utils.Array<Body> bodies = new com.badlogic.gdx.utils.Array<Body>();

    public loadGame(tankStars load) {
        this.load = load;
        main = new Texture("Terrain.jpg");
        playCam = new OrthographicCamera();
        stage = new Stage(new StretchViewport(1920, 1080, playCam));
        Gdx.input.setInputProcessor(stage);
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));
    }

    @Override
    public void show() {
        stage.clear();
        stage.draw();
        load.batch.setProjectionMatrix(playCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


        world = new World(new Vector2(0, -9.81f), true);
        this.world.setContactListener(new Collision());
        b2dr = new Box2DDebugRenderer();
        playCam = new OrthographicCamera(Gdx.graphics.getWidth() * 3, Gdx.graphics.getHeight() * 3);
        Gdx.input.setInputProcessor(new InputController() {
            @Override
            public boolean keyDown(int keycode) {
                switch (keycode) {
                    case Input.Keys.W:
                        movement2.x = speed2;
                        Play.count1++;
                        //fuel2();
                        break;
                    case Input.Keys.S:
                        movement.x = speed;
                        Play.count++;
                        //fuel1();
                        break;
                    case Input.Keys.A:
                        movement.x = -speed;
                        Play.count++;
                        //fuel1();
                        break;
                    case Input.Keys.D:
                        movement2.x = -speed2;
                        Play.count1++;
                        //fuel2();
                        break;
                    case Input.Keys.SPACE:
                        shoot1();
                        break;
                    case Input.Keys.ENTER:
                        shoot2();
                        break;
                }
                return true;
            }

            @Override
            public boolean keyUp(int keycode) {
                switch (keycode) {
                    case Input.Keys.W:
                    case Input.Keys.S:
                    case Input.Keys.A:
                        movement.x = 0;
                        break;
                    case Input.Keys.D:
                        movement2.x = 0;
                }
                return true;
            }
        });

        //body def
        BodyDef ball = new BodyDef();
        FixtureDef ballFix = new FixtureDef();


        //GROUND
        //BODY DEFINITION
        BodyDef ground = new BodyDef();
        FixtureDef groundFix = new FixtureDef();

        ground.type = BodyDef.BodyType.StaticBody;
        ground.position.set(0, 0);

        //Ground shape
        ChainShape groundShape = new ChainShape();
        groundShape.createChain(new Vector2[]{
                new Vector2(-350 * 3, -88 * 3),
                new Vector2(-281 * 3, -90 * 3),
                new Vector2(-280 * 3, -90 * 3),
                new Vector2(-266 * 3, -94 * 3),
                new Vector2(-265 * 3, -94 * 3),
                new Vector2(-166 * 3, -92 * 3),
                new Vector2(-165 * 3, -92 * 3),
                new Vector2(-51 * 3, -68 * 3),
                new Vector2(-50 * 3, -68 * 3),
                new Vector2(-1 * 3, -68 * 3),
                new Vector2(0, -68 * 3),
                new Vector2(100 * 3, -82 * 3),
                new Vector2(101 * 3, -82 * 3),
                new Vector2(160 * 3, -92 * 3),
                new Vector2(161 * 3, -92 * 3),
                new Vector2(350 * 3, -88 * 3),
        });


        //fixture
        groundFix.shape = groundShape;
        groundFix.friction = 1f;
        groundFix.restitution = 0;

        //world.createBody(ball).createFixture(ballFix);
        Body ground1 = world.createBody(ground);
        ground1.createFixture(groundFix).setUserData("ground");

        groundShape.dispose();

        //Box
        ball.type = BodyDef.BodyType.DynamicBody;
        ball.fixedRotation = true;
        ball.position.set((float)Play.t1x,(float)Play.t1y);

        //Box shape
        PolygonShape boxShape = new PolygonShape();

        boxShape.setAsBox(10, 10);

        //fixture
        ballFix.shape = boxShape;
        ballFix.density = 1;
        ballFix.friction = 2f;
        ballFix.restitution = 0;

        box = world.createBody(ball);

        box.createFixture(ballFix).setUserData("box");
        vsTemp.spriteF.setSize(20, 20);
        vsTemp.spriteF.setOrigin(vsTemp.spriteF.getWidth() / 2, vsTemp.spriteF.getHeight() / 2);
        box.setUserData(vsTemp.spriteF);

        boxShape.dispose();

        box.applyAngularImpulse(5, true);

        //BOX2
        ball.type = BodyDef.BodyType.DynamicBody;
        ball.fixedRotation = true;
        ball.position.set((float)Play.t2x,(float)Play.t2y);

        //Box shape - 2
        PolygonShape boxShape2 = new PolygonShape();
        boxShape2.setAsBox(10, 10);

        //fixture
        ballFix.shape = boxShape2;
        ballFix.density = 1;
        ballFix.friction = 2f;
        ballFix.restitution = 0;

        box2 = world.createBody(ball);
        box2.createFixture(ballFix).setUserData("box2");

        vsTemp.spriteB.setSize(20, 20);
        vsTemp.spriteB.setOrigin(vsTemp.spriteB.getWidth() / 2, vsTemp.spriteB.getHeight() / 2);
        box2.setUserData(vsTemp.spriteB);

        boxShape2.dispose();

        box2.applyAngularImpulse(5, true);

        vsTemp.spriteB.flip(true, false);


        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


    }

    @Override
    public void render(float delta) {
        update(delta);
//        Gdx.gl.glClearColor(0,0,0,1);
//        Gdx.gl.glClear(Gdx.gl.GL_COLOR_BUFFER_BIT);
        world.step(1 / 60f, 8, 3);
        box.applyForceToCenter(movement, true);
        box2.applyForceToCenter(movement2, true);

        load.batch.begin();
        load.batch.draw(main, 0, 0, 1920, 1080);

//        world.getBodies(bodies);
//        for (Body body : bodies) {
//            System.out.println(body.getUserData());
        if (box.getUserData() != null && box.getUserData() instanceof Sprite) {
            Sprite sprite = (Sprite) box.getUserData();
            sprite.setPosition(box.getPosition().x + (900), box.getPosition().y + 570);
            sprite.setSize(200, 150);
            sprite.draw(load.batch);

        }

        if (box2.getUserData() != null && box2.getUserData() instanceof Sprite) {
            Sprite sprite = (Sprite) box2.getUserData();
            sprite.setPosition(box2.getPosition().x + (800), box2.getPosition().y + 570);
            sprite.setSize(300, 150);
            sprite.draw(load.batch);

        }
        if(Play.count==0|| Play.count==1){
            //System.out.println("you wasted "+count + " chance");
            fuel1 = new Sprite(new Texture("fuel1.png"));
            fuel1.setPosition(0,0);
            fuel1.setSize(600,250);
            fuel1.draw(load.batch);

        }
        if (Play.count ==2){
            //System.out.println(count);
            fuel2 = new Sprite(new Texture("fuel2.png"));
            fuel2.setPosition(0,0);
            fuel2.setSize(600,250);
            fuel2.draw(load.batch);
        }
        if (Play.count==3){
            //System.out.println(count);
            fuel3 = new Sprite(new Texture("fuel3.png"));
            fuel3.setPosition(0,0);
            fuel3.setSize(600,250);
            fuel3.draw(load.batch);
        }
        if (Play.count==4){
            fuel4 = new Sprite(new Texture("fuel4.png"));
            fuel4.setPosition(0,0);
            fuel4.setSize(600,250);
            fuel4.draw(load.batch);

        }
        if (Play.count==5){
            Play.count=0;
        }
        if (Play.count1==0|| Play.count1==1){
            fuel1t2 = new Sprite(new Texture("fuel1.png"));
            fuel1t2.setSize(600,250);
            fuel1t2.setPosition(1500,0);
            fuel1t2.draw(load.batch);


        }
        if (Play.count1==2){
            fuel2t2 = new Sprite(new Texture("fuel2.png"));
            fuel2t2.setPosition(1500,0);
            fuel2t2.setSize(600,250);
            fuel2t2.draw(load.batch);

        }
        if (Play.count1==3){
            fuel3t2 = new Sprite(new Texture("fuel3.png"));
            fuel3t2.setPosition(1500,0);
            fuel3t2.setSize(600,250);
            fuel3t2.draw(load.batch);

        }
        if (Play.count1==4){
            fuel4t2 = new Sprite(new Texture("fuel4.png"));
            fuel4t2.setPosition(1500,0);
            fuel4t2.setSize(600,250);
            fuel4t2.draw(load.batch);
            //count1=0;

        }
        if (Play.count1==5){
            Play.count1=0;
        }


        if (Play.c==0){
            h11 = new Sprite(new Texture("p1h1.png"));
            h11.setPosition(0,900);
            h11.setSize(400,100);
            h11.draw(load.batch);
        }
        if (Play.c==1){
            h12 = new Sprite(new Texture("p1h2.png"));
            h12.setPosition(0,900);
            h12.setSize(400,100);
            h12.draw(load.batch);
        }

        if (Play.c==2){
            h13 = new Sprite(new Texture("p1h3.png"));
            h13.setPosition(0,900);
            h13.setSize(350,100);
            h13.draw(load.batch);
        }
        if (Play.c1==0){
            h21 = new Sprite(new Texture("p2h1.png"));
            h21.setPosition(1525,900);
            h21.setSize(350,100);
            h21.draw(load.batch);
        }
        if (Play.c1==1){
            h22 = new Sprite(new Texture("p2h2.png"));
            h22.setPosition(1525,900);
            h22.setSize(350,100);
            h22.draw(load.batch);
        }
        if (Play.c1==2){
            h23 = new Sprite(new Texture("p2h3.png"));
            h23.setPosition(1525,900);
            h23.setSize(350,100);
            h23.draw(load.batch);
        }

        load.batch.end();
        if(Gdx.input.isTouched()){
            load.setScreen(new pauseGame(load));
        }

        b2dr.render(world, playCam.combined);

    }

    public void update(float delta) {
        stage.act(delta);

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {


    }

    @Override
    public void dispose() {
        load.batch.dispose();
        //stage.dispose();
        world.dispose();
        b2dr.dispose();
        vsTemp.spriteF.getTexture().dispose();

    }
    public void shoot1(){
        BodyDef ballOne = new BodyDef();
        ballOne.type = BodyDef.BodyType.DynamicBody;
        ballOne.position.set(box.getPosition().x, box.getPosition().y + 30); // 0 to 1 meter

        this.world.setContactListener(new Collision());

        //ball shape
        CircleShape ballShape = new CircleShape();

        ballShape.setRadius(15f);
        // fixture def
        FixtureDef ballFix = new FixtureDef();
        ballFix.density = 1.5f;   //kg/m^2
        ballFix.shape = ballShape;
        ballFix.friction = 0.25f;
        ballFix.restitution = 0f; // bounciness

        //world.createBody(ball).createFixture(ballFix);
        Body ball1 = world.createBody(ballOne);

        ball1.applyLinearImpulse(1900000, 1000000, ball1.getPosition().x + 500, ball1.getPosition().y + 500, true);
        ball1.createFixture(ballFix).setUserData("ball1");
        //ballShape.dispose();

    }
    public void shoot2(){
        BodyDef ballTwo = new BodyDef();
        ballTwo.type = BodyDef.BodyType.DynamicBody;
        ballTwo.position.set(box2.getPosition().x, box2.getPosition().y + 30); // 0 to 1 meter


        //ball shape
        CircleShape ballShape = new CircleShape();

        ballShape.setRadius(15f);

        // fixture def
        FixtureDef ballFix = new FixtureDef();
        ballFix.density = 2.5f;   //kg/m^2
        ballFix.shape = ballShape;
        ballFix.friction = 0.25f;
        ballFix.restitution = 0f; // bounciness

        //world.createBody(ball).createFixture(ballFix);

        Body ball2 = world.createBody(ballTwo);

        ball2.applyLinearImpulse(-190000, 100000, ball2.getPosition().x - 500, ball2.getPosition().y + 500, true);
        ball2.createFixture(ballFix).setUserData("ball2");

        //ballShape.dispose();

    }

//    private void resumeButton(){
//        pauseG = new TextButton("Resume", skin);
//        pauseG.setSize(200, 100);
//        pauseG.setPosition(0,0);
//        pauseG.setColor(1,1,1,1);
//        pauseG.addListener(new ClickListener() {
//            @Override
//            public void clicked(InputEvent event, float x, float y) {
//                System.out.println("hello");
//                play.setScreen(new pauseGame(play));
//            }
//        });
//        stage.addActor(pauseG);
//    }


}
