package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;


public class Explosion {

    SpriteBatch batch;

    public static final float frameLength = 0.2f;
    public static final int frameCount = 8;
    public static final int size = 32;

    private static Animation animeexp = null;
    float x, y;
    float stateTime;

    public boolean remove = false;

    public Explosion(float x, float y) {
        this.x = x - frameCount;
        this.y = y - frameCount;
        stateTime = 0;

        if (animeexp == null) {
            animeexp = new Animation(frameLength, TextureRegion.split(new Texture("explosion.jpg"), size, size)[0]);

        }
    }

    public void update(float delta) {
        stateTime += delta;
        if (animeexp.isAnimationFinished(stateTime)) {
            remove = true;
        }
    }

}
