package Screens;

public class Multiply {
    private int x;
    private int y;

    public Multiply(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int Multi(){
        return x * y;
    }

}

