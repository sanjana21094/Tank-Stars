package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

public class winner implements Screen {
    private tankStars win;
    private Stage stage;
    private Skin skin;

    private Texture winner1;
    private Texture win1;
    private Texture win2;
    private OrthographicCamera winCam;
    public static Sprite spriteF;
    public static Sprite spriteB;

    private InputEvent event;

    public winner(tankStars win) {
        this.win = win;
        Gdx.input.setInputProcessor(stage);
        winCam = new OrthographicCamera();
        stage = new Stage();
        skin = new Skin();
        winner1 = new Texture("Winner.jpg");
        stage = new Stage(new StretchViewport(1920,1080,winCam));
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));

    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        stage.draw();
        win.batch.setProjectionMatrix(winCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    }

    @Override
    public void render(float delta) {
        update(delta);
        win.batch.begin();
        win.batch.draw(winner1, 0, 0, 1920, 1080);


        if (Play.c==3){
            if(choose.c1==1){
                spriteB = new Sprite(new Texture("tank1.jpg"));
                win.batch.draw(spriteB, 0, 0, 860, 364);
            }
            if(choose.c1==2){
                spriteB = new Sprite(new Texture("tank 2.jpg"));
                win.batch.draw(spriteB, 0, 0, 600, 320);
            }
            if(choose.c1==3){
                spriteB = new Sprite(new Texture("TANK3.jpg"));
                win.batch.draw(spriteB, 0, 0, 860, 364);
            }

        }
        if (Play.c1 == 3){

            if(chooseTank.c==1){
                spriteF = new Sprite(new Texture("tank1.jpg"));
                win.batch.draw(spriteF, 0, 0, 860, 364);
            }
            if(chooseTank.c==2){
                spriteF = new Sprite(new Texture("tank 2.jpg"));
                win.batch.draw(spriteF, 0, 0, 600, 320);
            }
            if(chooseTank.c==3){
                spriteF = new Sprite(new Texture("TANK3.jpg"));
                win.batch.draw(spriteF, 0, 0, 864, 364);
            }

        }

        win.batch.end();

    }

    public void update(float delta){
        stage.act(delta);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
        win.batch.dispose();

    }


}