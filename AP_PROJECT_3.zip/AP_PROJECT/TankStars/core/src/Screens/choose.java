package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.SpriteDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

import java.util.ArrayList;

public class choose implements Screen {
    public static int c1 = 0 ;
    private tankStars tank;
    private Stage stage;
    private Skin skin;
    private Texture choose;

    private TextButton startGame;
    private TextButton op1;
    private TextButton op2;
    private TextButton op3;
    private TextButton next;
    private OrthographicCamera tankCam;
    private InputEvent event;

    private Texture tankF;
    private Texture tankB;
    private Texture tankA;
    private Image imageF;
    private Sprite spriteF;


    public choose(tankStars tank) {
        this.tank = tank;
        Gdx.input.setInputProcessor(stage);
        choose = new Texture("temp2.jpg");
        tankF = new Texture("tank1.jpg");
        imageF = new Image(tankF);
        tankB= new Texture("tank 2.jpg");
        tankA = new Texture("TANK3.jpg");
        tankCam = new OrthographicCamera();
        stage = new Stage(new StretchViewport(1920,1080,tankCam));
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));
    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        stage.draw();
        tank.batch.setProjectionMatrix(tankCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


    }

    @Override
    public void render(float delta) {
        update(delta);
        tank.batch.begin();
        tank.batch.draw(choose, 0, 0, 1920, 1080);
        tank.batch.end();
        tanks();
        stage.act();
        stage.draw();
        startButton();
    }

    public void update(float delta) {
        stage.act(delta);
    }
    public void tanks(){
        tank.batch.begin();
        tank.batch.draw(tankF, 700, 250, 800, 304);
        tank.batch.draw(tankA, 1480, 335, 450, 202);
        tank.batch.draw(tankB, -10, 300, 640, 264);
        tank.batch.end();

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        tank.batch.dispose();
        stage.dispose();

    }

    private void startButton(){
//            startGame.addListener(new ClickListener(){
//                @Override
//                public void clicked(InputEvent event, float x, float y){
//                    tank.setScreen(new choose(tank));
//                }
//            });

        op1= new TextButton("F",skin);
        op1.setPosition(900, 300);
        op1.setSize(350, 200);
        op1.getLabel().setFontScale(4);
        op1.setColor(0,0,0,0);
        stage.addActor(op1);
        op1.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                c1=1;
                tank.setScreen(new vsTemp(tank));
            }
        });

        op2 = new TextButton("B",skin);
        op2.setPosition(100, 350);
        op2.setSize(500, 200);
        op2.getLabel().setFontScale(4);
        op2.setColor(0,0,0,0);
        stage.addActor(op2);
        op2.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                //tank.setScreen(new choose(tank));
                c1=2;
                tank.setScreen(new vsTemp(tank));
            }
        });

        op3 = new TextButton("A",skin);
        op3.setPosition(1630, 435);
        op3.setSize(250, 100);
        op3.getLabel().setFontScale(4);
        op3.setColor(0,0,0,0);
        stage.addActor(op3);
        op3.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                c1=3;
                tank.setScreen(new vsTemp(tank));
            }
        });


            /*
            nextTank.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y){
                    tank.setScreen(new vsTemp(tank));
                }
            });
            */

    }
}
