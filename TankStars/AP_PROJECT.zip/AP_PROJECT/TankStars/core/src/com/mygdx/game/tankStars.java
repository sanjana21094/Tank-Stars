package com.mygdx.game;

import Screens.*;
import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.Viewport;

public class tankStars extends Game {

	private HomeScreen homeScreen;
	public SpriteBatch batch;
	public Stage stage;
    private OrthographicCamera camera;
	private Viewport viewport;
	private MenuScreen menuScreen;

	@Override
	public void create() {
		batch = new SpriteBatch();
		setScreen(new HomeScreen(this));

	}

	@Override
	public void render() {
		super.render();

	}

	@Override
	public void dispose() {
		batch.dispose();

	}
}
