package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

public class vsTemp implements Screen {
    private tankStars vs;
    private Stage stage;
    private Skin skin;
    private Texture temp;
    private OrthographicCamera vsCam;

    public vsTemp(tankStars vs) {
        this.vs = vs;
        Gdx.input.setInputProcessor(stage);
        vsCam = new OrthographicCamera();
        stage = new Stage();
        skin = new Skin();
        temp = new Texture("VS .jpg");
        stage = new Stage(new StretchViewport(1920,1080,vsCam));
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        stage.draw();
        vs.batch.setProjectionMatrix(vsCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    }

    @Override
    public void render(float delta) {
        update(delta);
        vs.batch.begin();
        vs.batch.draw(temp, 0, 0, 1920, 1080);
        vs.batch.end();
        if(Gdx.input.isTouched()){
            vs.setScreen(new mainGame(vs));
        }

    }

    public void update(float delta){
        stage.act(delta);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
        vs.batch.dispose();

    }
}
