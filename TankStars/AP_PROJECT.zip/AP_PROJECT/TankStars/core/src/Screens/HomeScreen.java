package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankStars;

public class HomeScreen implements Screen {
    private tankStars home;
    private Texture textHome;
    private Texture textplayBut;


    private SpriteBatch batch;


    public HomeScreen(tankStars home) {
        this.home = home;
        textHome = new Texture("homepage.jpg");
        textplayBut = new Texture("playbutton.jpg");

    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(home.stage);

    }

    @Override
    public void render(float delta) {

        home.batch.begin();
        home.batch.draw(textHome,0,0,640,480);
        home.batch.draw(textplayBut, 500, 20,130 ,100);
        home.batch.end();
        if(Gdx.input.isTouched()){
            home.setScreen(new MenuScreen(home));
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        batch.dispose();

        //textHome.dispose();

    }
}
