package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

public class MenuScreen implements Screen {

    private tankStars menu;
    private Stage stage;
    private Skin skin;
    private TextButton newGame;
    private TextButton savedGame;
    private TextButton exitGame;
    private Texture textMenu;
    private OrthographicCamera menuCam;

    private InputEvent event;

    public MenuScreen(tankStars menu) {
        this.menu = menu;
        Gdx.input.setInputProcessor(stage);
        textMenu = new Texture("menu.jpg");
        menuCam = new OrthographicCamera();
        stage = new Stage(new StretchViewport(1920,1080,menuCam));
        //Gdx.input.setInputProcessor(stage);
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));
        //event = new InputEvent();


    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        stage.draw();
        menu.batch.setProjectionMatrix(menuCam.combined);
        stage.draw();
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    }

    @Override
    public void render(float delta) {
        update(delta);
        menu.batch.begin();
        menu.batch.draw(textMenu, 0, 0, 1920, 1080);
        menu.batch.end();
        stage.act();
        stage.draw();
        menuButtons();

    }
    public void update(float delta){
        stage.act(delta);

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        menu.batch.dispose();
        stage.dispose();

    }

    private void menuButtons(){
        newGame = new TextButton("NEW GAME",skin);
        newGame.setPosition(700, 500);
        newGame.setSize(500, 100);
        newGame.getLabel().setFontScale(4);
        newGame.setColor(0,0,0,0);
        stage.addActor(newGame);


        savedGame = new TextButton("SAVED GAME",skin);
        savedGame.setPosition(700, 300);
        savedGame.setSize(500, 100);
        savedGame.getLabel().setFontScale(4);
        savedGame.setColor(0,0,0,0);
        stage.addActor(savedGame);


        exitGame = new TextButton("EXIT GAME",skin);
        exitGame.setPosition(700,100);
        exitGame.setSize(500, 100);
        exitGame.getLabel().setFontScale(4);
        exitGame.setColor(0,0,0,0);

        newGame.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                menu.setScreen(new chooseTank(menu));
            }
        });

        exitGame.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y){
                System.exit(0);
            }
        });
        menu.batch.begin();
        stage.addActor(newGame);
        stage.addActor(savedGame);
        stage.addActor(exitGame);
        menu.batch.end();

    }
}
