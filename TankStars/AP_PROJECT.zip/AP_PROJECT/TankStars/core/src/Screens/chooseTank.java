package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.tankStars;

public class chooseTank implements Screen {
    public static int c = 0 ;
    private tankStars tank;
    private Stage stage;
    private Skin skin;
    private Texture choose;

    private TextButton startGame;
    private OrthographicCamera tankCam;
    private InputEvent event;
    private Texture tank2;



    public chooseTank(tankStars tank) {
        this.tank = tank;
        Gdx.input.setInputProcessor(stage);
        choose = new Texture("PLAYER 1.jpg");
        tank2 = new Texture("PLAYER 2.jpg");
        tankCam = new OrthographicCamera();
        stage = new Stage(new StretchViewport(1920,1080,tankCam));
        skin = new Skin(Gdx.files.internal("skin/neon-ui.json"));
    }


        @Override
        public void show() {
            Gdx.input.setInputProcessor(stage);
            stage.clear();
            stage.draw();
            tank.batch.setProjectionMatrix(tankCam.combined);
            stage.draw();
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


        }

        @Override
        public void render(float delta) {
            update(delta);
            tank.batch.begin();
            tank.batch.draw(choose, 0, 0, 1920, 1080);
            tank.batch.end();
            if (Gdx.input.isTouched()){
                c=1;
            }
            if (c==1){
                tank1();
            }
            stage.act();
            stage.draw();
            startButton();
        }

        public void update(float delta) {
            stage.act(delta);
        }
        public void tank1(){
            tank.batch.begin();
            tank.batch.draw(tank2, 0, 0, 1920, 1080);
            tank.batch.end();

        }


        @Override
        public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
        }

        @Override
        public void pause() {

        }

        @Override
        public void resume() {

        }

        @Override
        public void hide() {

        }

        @Override
        public void dispose() {
            tank.batch.dispose();
            stage.dispose();

        }

        private void startButton(){
            startGame = new TextButton("START",skin);
            startGame.setPosition(1350, 50);
            startGame.setSize(500, 100);
            startGame.getLabel().setFontScale(4);
            startGame.setColor(0,0,1,0);
            stage.addActor(startGame);

            startGame.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y){
                    tank.setScreen(new vsTemp(tank));
                }
            });
        }
}
